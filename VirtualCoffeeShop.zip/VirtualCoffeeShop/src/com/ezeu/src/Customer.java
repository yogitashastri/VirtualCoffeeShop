package com.ezeu.src;

import java.util.ArrayList;
import java.util.Scanner;

public class Customer {

	public void customerFeature() {
		
		Scanner sc1 = new Scanner(System.in);
		
		ArrayList<String> a = Shop.al;
		
		ArrayList<String> b = Shop.all;
		
		System.out.println("Hello Customer");
		
		System.out.println("the Coffee menu is "+a);
		
		System.out.println("select the index number of the coffee you want");
		
		int val = sc1.nextInt();
		
		if(val < a.size()){
		
		System.out.println("selected coffee is "+a.get(val));
		
		System.out.println("the Topping menu is "+b);
		System.out.println("select the index number of topping you want");
		
	
		int num= new Scanner(System.in).nextInt();
		
		System.out.println("selected topping is "+b.get(num));
		
		System.out.println("You have selected Coffee of type  = "+a.get(val)+" "+"with topping = "+b.get(num));
		}
		
		else
		
			System.out.println("You have given wrong input");
		
		
	}
}
