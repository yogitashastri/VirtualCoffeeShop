package com.ezeu.src;

import java.util.ArrayList;
import java.util.Scanner;

public class Shop {
  
  static Scanner sc1 = new Scanner(System.in);
  
  static Scanner sc2 = new Scanner(System.in);
	
  static ArrayList<String> al = new ArrayList<String>();
  
  static ArrayList<String> all = new ArrayList<String>();

  public Shop() {
	
	al.add("Cappuccino");
	al.add("Affogato");
	all.add("Nutella");
	all.add("Chocolate");
	
  }
  
  public static void addCoffee() {
	  
	  System.out.println("enter the name of the coffee which you want to add");
	  
	  String name = sc2.nextLine();
	  
	  al.add(name);
	  
	  showMenu();
	  
	  System.out.println("item added");
	  
  }
  
  public static void deleteCoffee() {
	  
	  System.out.println("enter the index number which you want to delete");
	  
	  showMenu();
	  
	  int val = sc1.nextInt();
	  
	  al.remove(val);
	  
	  showMenu();
	  
	  System.out.println("item deleted");
  }
  
  public static void showMenu() {
	  
	  System.out.println("the menu is "+al);
  }
  
  public static void addTopping() {
	  
	  System.out.println("enter the topping name which you want to add");
	  
	  String name = sc2.nextLine();
	  
	  all.add(name);
	  
	  showToppingMenu();
	  
	  System.out.println("topping added");
  }
  
  public static void deleteTopping() {
	  
	  System.out.println("enter the index number which you want to delete");
	  
	  showToppingMenu();
	  
	  int val = sc1.nextInt();
	  
	  all.remove(val);
	  
	  showToppingMenu();
	  
	  System.out.println("topping deleted");
  }
  
  public static void showToppingMenu(){
	  
	  System.out.println("the topping menu is "+all);
  }
  
}
