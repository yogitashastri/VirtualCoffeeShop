package com.ezeu.src;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Shop p = new Shop();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Hello Select your choice");
		
		System.out.println("1.Owner , 2.Customer");
		
		int choice = sc.nextInt();
		
		do {
			if(choice == 1) {
				
				new Owner().ownerFeature();
			}
			
			else if(choice == 2) {
				
				new Customer().customerFeature();
			}
			
			else {
				
				System.out.println("Enter correct choice");
			}
		}while(true);
		
	}
}
