package com.ezeu.src;

import java.util.Scanner;

public class Owner {

	public void ownerFeature() {
		
		Scanner sc1 = new Scanner(System.in);
		
		Scanner sc2 = new Scanner(System.in);
		
		System.out.println("Hello Owner");
		
		System.out.println("Select one choice");
		
		System.out.println("1.Coffee , 2.Toppings");
		
		int choice1 = sc1.nextInt();
		
		if(choice1 == 1) {
			
			System.out.println("You are selecte dto edit a coffee");
			
			System.out.println("Enter your choice of edit");
			
			System.out.println("1.add coffee , 2.delete coffee , 3.show menu");
			
			int choice2 = sc2.nextInt();
			
			switch(choice2) {
			
			case 1 : System.out.println("add coffee");
			         Shop.addCoffee();
			         break;
			         
			case 2 : System.out.println("delete coffee");
			         Shop.deleteCoffee();
			         break;
			         
			case 3 : System.out.println("Show menu");
			         Shop.showMenu();
			         break;
			         
			default : System.out.println("enter correct choice");
			}
		}
		
		else if(choice1 == 2) {
			
			System.out.println("you selected to edit toppings");
			
			System.out.println("again enter your choice of edit");
			
			System.out.println("1.add topping , 2.delete topping , 3.show menu\" ");
			
			int choice3 = sc2.nextInt();
			
			System.out.println("your choice is "+choice3);
			
			switch(choice3) {
			
			case 1 : System.out.println("add topping");
			         Shop.addTopping();
			         break;
			         
			case 2 : System.out.println("delete topping");
			         Shop.deleteTopping();
			         break;
			         
			case 3 : System.out.println("Show topping menu");
			         Shop.showToppingMenu();
			         break;
			         
		default : System.out.println("Enter correct choice");
			}
		}
		
		else 
			   System.out.println("enter a valid choice");
		
		
		    
		
	}
}
